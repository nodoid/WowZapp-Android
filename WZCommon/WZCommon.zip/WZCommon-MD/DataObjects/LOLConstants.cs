namespace WZCommon
{
    public class WZConstants
    {
        //
        // Database
        //
        public const string DBClauseSyncOff = "PRAGMA SYNCHRONOUS=OFF;";
        public const string DBClauseVacuum = "VACUUM;";
		
    }
}

