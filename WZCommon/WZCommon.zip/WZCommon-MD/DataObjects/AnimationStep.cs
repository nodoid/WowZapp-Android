// Created by Dimitris Tavlikos, dimitris@tavlikos.com, http://software.tavlikos.com
using System;

namespace WZCommon
{
	public class AnimationStep
	{
		public AnimationStep ()
		{
		}
	}



	public class AnimationFrame
	{

		public AnimationFrame()
		{
		}

	}//end class AnimationFrame



	public class AnimationLayer
	{

		public AnimationLayer()
		{
		}


	}//end class AnimationLayer




	public class AnimationDrawing
	{

		public AnimationDrawing()
		{
		}
	}



	public class AnimationBrush
	{

		public AnimationBrush()
		{
		}

	}//end class AnimationBrush



	public class AnimationTransition
	{

		public AnimationTransition()
		{
		}

	}//end class AnimationTransition


}

